#include<stdio.h>
#include<Math.h>
int main()
{ 
   	printf("Priyanshu Bist \n Roll No.=11393\n");
    int num1,num2,ch;
	printf("Enter the first value: \n");
	scanf(" %d",&num1);
	printf("Enter the second value: \n");
	scanf(" %d",&num2);
	printf("Enter the choice from the menu \n 1.Addition \n 2.Subtraction \n 3.Multiplacation \n 4.Division \n");
	scanf(" %d",&ch);
	switch(ch)
	{
		case 1: printf("The value after addition is %d.",(num1+num2));
		break;
		case 2: printf("The value after subtraction is %d.",(num1-num2));
		break;
		case 3: printf("The value after product is %d.",(num1*num2));
		break;
		case 4:
		 if(num2!=0)
		 printf("The value after division is %d.",(num1/num2));
		 else
		 printf("The Value is Infinity");
		 break;
		default: printf("Wrong Input");
	}
	return 0;
}

