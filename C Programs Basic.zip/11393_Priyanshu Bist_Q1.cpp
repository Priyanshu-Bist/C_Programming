#include<stdio.h>
#include<conio.h>
int main()
{
	printf("Name = Priyanshu Bist\nRoll No. = 11393\n");	
	int a ;
	printf("Enter the number:\n");
	scanf("%d" , &a);	
	if(a % 2 == 0 && a % 2 != 1)
		printf("Even");
	
	else 
		printf("Odd",a);
}
