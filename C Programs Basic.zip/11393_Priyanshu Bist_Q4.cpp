#include<stdio.h>
#include<conio.h>
int main()
{
	printf("Priyanshu Bist \n Roll No = 11393\n");	
	int a , b , c ;
	float d ;	
	printf("Price of old scooter \n");
	scanf("%d" , &a);	
	printf("Repair amount \n");
	scanf("%d" , &b);
	printf("Selling Price \n");
	scanf("%d" , &c);
	d = (c-(a+b));
	d = (d / c) * 100 ;
	printf("Your Gain Percent is %f" , d);
		
}
