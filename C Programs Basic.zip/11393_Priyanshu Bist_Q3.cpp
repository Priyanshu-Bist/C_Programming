#include<stdio.h>
int main()
{
	printf("Priyanshu Bist  \nRoll No. = 11393\n");	
	int side , x , y , a , b ;
	printf("Enter the X-coordinate of the left bottom vertex \n");
	scanf("%d" , &x);
	printf("Enter the y coordinate of the left bottom vertex \n");
	scanf("%d" , &y);
	printf("Enter Side Length \n");
	scanf("%d" , &side);
	a = x + side/2 ;
	b = y + side/2 ;
	printf("Centre X coordinate %d \n",a);
	printf("Centre Y coordinate %d",b);	
}
