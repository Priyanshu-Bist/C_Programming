#include<stdio.h>
 
int main(){
	printf("Priyanshu Bist \n Roll No. = 11393\n");
	
	int roll_no , marks ;
	char name[20];
	printf("Enter the roll number of the student \n");
	scanf("%d" , &roll_no);
	printf("Enter the name of the student \n");
	scanf("%s" , &name);
	
	printf("Enter the total marks of the student \n");
	scanf("%d" , &marks);

	if(marks >100){
		printf("Enter Valid Marks");
	}

	if(marks >=80 && marks <= 100){
		printf("Grade details \n");
		printf("\t %d" , roll_no);
	    printf("\t %s" , name);
	    printf("\t %d" , marks);
		printf("\t A");
	}
		
	if(marks>=60 && marks <= 80){
		printf("Grade details \n");
		printf("\t %d" , roll_no);
	    printf("\t %s" , name);
	    printf("\t %d" , marks);
		printf("\t B");
	}
		
	if(marks>=40 && marks <= 60){
		printf("Grade details \n");
		printf("\t %d" , roll_no);
	    printf("\t %s" , name);
	    printf("\t %d" , marks);
		printf("\t C");
	}

	if(marks<40){
		printf("Grade details \n");
		printf("\t %d" , roll_no);
	    printf("\t %s" , name);
	    printf("\t %d" , marks);
		printf("\t Fail");
	}
	


}
