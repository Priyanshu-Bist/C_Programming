#include<stdio.h>

int main(){
	
	printf("Priyanshu Bist \n Roll No = 11393\n");
		
	int age ;
	printf("Age:");
	scanf("%d" , &age);
	
	if(age <= 3){
		printf("Toddler \n");
		printf("Allowed");
	}
	
	if(age >= 4 && age <= 12){
		printf("Junior \n");
		printf("Allowed");
	}
	
	if(age >= 13 && age <= 17){
		printf("Teanager \n");
		printf("Allowed");
	}
	
	if(age >= 18){
		printf("Not Allowed");
	}
}
