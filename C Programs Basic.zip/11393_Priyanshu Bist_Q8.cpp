#include<stdio.h>

int main()
{
	printf("Priyanshu Bist \n Roll No. = 11393 \n");
	int usid; 
	char *user;
	float units , bill;
	printf("Enter the user id of user \n");
	scanf("%d" , &usid);
	printf("Enter the name of user \n");
	scanf("%s" , &user);
	printf("Enter the number of Units consumed by user \n");
	scanf("%f" , &units);

	if(units<=100)
	{
		bill = 1 * units ;
		if(units > 50){
		printf(" Total Bill = %f\n" , bill);
		}
		
		if(units <= 50 ){
			printf(" Total Bill = 50");
		}
	}
	
	if(units > 100 && units <= 300){
		bill = 2 * units ;
		printf(" Total Bill = %f" , bill);	
	}
	
		if(units>=300){
		bill = 3 * units ;
		if(units <= 1000){
		printf(" Total Bill = %f\n" , bill);
		}
		
		if(units > 1000 ){
			printf("Total Bill = %f" , bill + (bill*0.15));
		}
	}

}
