#include <stdio.h>
int main()
{	
	printf("Priyanshu Bist \n Roll No=11393 \n");
	int a,b,c,d;
	printf("Number of Student:");
	scanf("%d",&a);
	printf("Number of teams:");
	scanf("%d",&b);
	c = a/b ;
	printf("Number of Sudents in each team is %d",c);
	d = a-(b*c);
	printf(" and left out is %d",d);
}
