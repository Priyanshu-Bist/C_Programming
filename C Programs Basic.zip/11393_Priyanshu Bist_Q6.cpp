#include<stdio.h>

int main(){
	
	printf("Priyanshu Bist \n Roll No = 11393 \n");

	int a , b;
	printf("Enter your Number ");
	scanf("%d" , &a);
	b = a * a ;
	printf("Square is %d" , b);
	
	if(b>10 && b<100){
		
		int c , d , e;
		c = b % 10 ;
		d = b / 10 ;
		e = c + d ;
			if( e==a )
				printf("\nThis is Kaprekar Number.");
			else
				printf("\nThis is not Kaprekar Number.");		
	}
	
		if(b>=100 && b<1000){
		
		int c , d , e ;
		c = b % 100 ;
		d = b / 10 ;
		e = c + d ;
			if( e==a )
				printf("\nThis is Kaprekar Number.");
			else
				printf("\nThis is not Kaprekar Number.");		
	}
	
		if(b>=1000 && b<10000){
		
		int c , d , e;
		c = b % 100 ;
		d = b / 100 ;
		e = c + d ;
			if( e==a )
				printf("\nThis is Kaprekar Number.");
			else
				printf("\nThis is not Kaprekar Number.");		
	}
	
		if(b>10000 && b<100000){
		
		int c , d , e;
		c = b % 1000 ;
		d = b / 100 ;
		e = c + d ;
			if( e==a )
				printf("\nThis is Kaprekar Number.");
			else
				printf("\nThis is not Kaprekar Number.");		
	}
	
		if(b>100000 && b<1000000){
		
		int c , d , e;
		c = b % 1000 ;
		d = b / 1000 ;
		e = c + d ;
			if( e==a )
				printf("\nThis is Kaprekar Number.");
			else
				printf("\nThis is not Kaprekar Number.");		
	}
	
		if(b>1000000 && b<10000000){
		
		int c , d , e;
		c = b % 10000 ;
		d = b / 1000 ;
		e = c + d ;
			if( e==a )
				printf("\nThis is Kaprekar Number.");
			else
				printf("\nThis is not Kaprekar Number.");		
	}
	
	if(b>10000000 && b<100000000){
		
		int c , d , e;
		c = b % 10000 ;
		d = b / 10000 ;
		e = c + d ;
			if( e==a )
				printf("\nThis is Kaprekar Number.");
			else
				printf("\nThis is not Kaprekar Number.");		
	}
	
	if(b>100000000 && b<1000000000){
		
		int c , d , e;
		c = b % 100000 ;
		d = b / 10000 ;
		e = c + d ;
			if( e==a )
				printf("\nThis is Kaprekar Number.");
			else
				printf("\nThis is not Kaprekar Number.");		
	}
	
	if(b>1000000000 && b<10000000000){
		
		int c , d , e;
		c = b % 100000 ;
		d = b / 100000 ;
		e = c + d ;
			if( e==a )
				printf("\nThis is Kaprekar Number.");
			else
				printf("\nThis is not Kaprekar Number.");		
	}
	
	if(b>1000000000 && b<2147483647){
		
		int c , d , e;
		c = b % 1000000 ;
		d = b / 100000 ;
		e = c + d ;
			if( e==a )
				printf("\nThis is Kaprekar Number.");
			else
				printf("\nThis is not Kaprekar Number.");		
	}	
	
	
}
