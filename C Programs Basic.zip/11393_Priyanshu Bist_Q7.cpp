#include<stdio.h>
int sumofdigits(int m){
	int pot = 10 , sum1 = 0 ;
	while(m != 0){
		sum1 = sum1 + (m % 10);
		m = (m / pot);
	}
	return sum1 ;
}
int main(){
	
	printf("Priyanshu Bist \n Roll No. = 11393 \n");
	
	int n , i = 2 , j = 0 , a[100] , sum = 0 , count = 0;
	printf("Enter a Number:");
	scanf("%d" , &n);
	
	int numSum = sumofdigits(n);
	
	
	while(n != 1 ){
			while( n%i == 0 ){
				n = n/i ;
				count++ ;
				
					for(; j<count ; j++ ){
						a[j] = i ;
					
					}
				}
		i++ ;
	
	
	}
	
	
	for( j = 0 ; j < count ; j++ ){
	sum = sum + sumofdigits(a[j]) ;
	}
	
	
	if (sum == numSum){
		printf("Number is smith number");
	} else {
		printf("Number is not a smith number");
	}
	
}
